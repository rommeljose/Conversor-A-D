#ifndef ___SIZE_T_H_
#define ___SIZE_T_H_

typedef	unsigned	size_t;		/* type yielded by sizeof */

#endif

